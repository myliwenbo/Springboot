package vip.xjdai.springbootthread;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootThreadApplicationTests {

    @Test
    void contextLoads() {
    }

}
